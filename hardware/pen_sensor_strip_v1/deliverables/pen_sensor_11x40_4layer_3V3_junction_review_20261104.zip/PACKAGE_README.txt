11 x 40 mm 四层笔杆板 · 2026-11-04

先读 hardware/pen_sensor_strip_v1/README.md。正式原理图、PCB、网表在该目录 easyeda_std/ 中，检查和 SHA256 在 verification/20261104/ 中。baselines/ 仅为修改前与候选比较资料。

附带的 firmware/mlx90393_sensor/mlx90393_sensor.ino 是旧单传感器迁移参考，不能作为当前板完整固件。源文件与已核验云端版本一致；本包为工程审核包，尚未完成制造和实物验收。
