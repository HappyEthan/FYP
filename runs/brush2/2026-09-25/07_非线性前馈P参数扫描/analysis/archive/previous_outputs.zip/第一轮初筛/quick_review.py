"""Read-only first-round review using the established measurement audit."""
from pathlib import Path
import importlib.util
import json
import numpy as np
import matplotlib.pyplot as plt

OUT=Path(__file__).resolve().parent
DAY=OUT.parents[2]
source=DAY/'06_非线性前馈难曲线对比/analysis/nonlinear_ff_p_selected_20260925/analyze.py'
spec=importlib.util.spec_from_file_location('previous_analysis',source)
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
runs=[base.load(p) for p in sorted((OUT.parents[1]/'raw').iterdir()) if (p/'manifest.json').exists()]
assert len(runs)==7 and all(r['audit']['eligible'] for r in runs)
assert len({tuple(r['audit']['hashes'][key] for key in
    ['strokeplan.npz','settings.json','feedforward.json','entry_profile.json']) for r in runs})==1
summary=dict(scope='First round, all seven full runs retained; C repeated twice, other settings once.',
    method='Full 40 s / 2001 points, logged EMA alpha=.3, measured minus target; no trimming, lag shift or extra smoothing.',
    runs=[dict(**r['audit'],metrics=r['metrics'],segments=r['segments']) for r in runs],
    repeated_C_response_difference_mae_uT=float(np.mean(abs(runs[2]['y']-runs[3]['y']))),
    recommendation='Focus next repeats on Kp0.5/cap0.8 and Kp1/cap0.8, reverse order; investigate baseline/contact repeatability before expanding the grid.')
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
fig,axes=plt.subplots(1,2,figsize=(14,4.7),sharex=True,sharey=True,layout='constrained')
for ax,indices,title in [(axes[0],[2,3],'同参数的两次重复：Kp=0.5，±0.4 mm'),
                         (axes[1],[4,6],'待复测候选：均为±0.8 mm')]:
    r=runs[indices[0]];ax.fill_between(r['t'],r['g']-20,r['g']+20,color='#94a3b8',alpha=.18)
    ax.plot(r['t'],r['g'],color='#111827',ls='--',lw=1.4,label='目标（阴影±20 µT）')
    for i,color in zip(indices,['#2563eb','#ea580c']):
        r=runs[i];c=r['audit']['control'];m=r['metrics']
        label=f"{r['folder'].name[:8]} · Kp={c['kp']:g} · MAE {m['mae_uT']:.1f}"
        ax.plot(r['t'],r['y'],color=color,lw=1.1,label=label)
    ax.set(title=title,xlabel='测量时间 / s',ylabel='磁响应 / µT',xlim=(0,40),ylim=(60,290))
    ax.legend(fontsize=9);ax.grid(alpha=.2)
fig.suptitle('第一轮初筛：参数差异与笔间状态差异并存；尚不能确定最优参数',fontsize=15)
fig.savefig(OUT/'第一轮关键对比.png',dpi=180,bbox_inches='tight');plt.close(fig)
lines=['---','project: 04-robot-control','status: active','---','','# 第一轮参数扫描简析','',
       '共7笔，全部完整40秒；C组两次，其余各一次。保留全部数据，不因误差大而删除C第一笔。',
       '所有输入快照哈希通过核对、测量传感器引用有效，四项共同输入哈希一致。','','| 时间 | Kp | 修正/mm | MAE/µT | P95/µT | ±20内 | 实际限幅占比 |',
       '|---|---:|---:|---:|---:|---:|---:|']
for r in runs:
    c=r['audit']['control'];m=r['metrics']
    lines.append(f"| {r['folder'].name[:8]} | {c['kp']:g} | ±{c['max_correction_mm']:g} | {m['mae_uT']:.1f} | {m['p95_abs_uT']:.1f} | {m['within20_pct']:.1f}% | {m['amplitude_cap_pct']:.1f}% |")
lines+=['','![关键对比](第一轮关键对比.png)','',
    '- F（Kp1/±0.8）本轮MAE最低、±20比例最高，但下降段平均实测高于目标25.2 µT，|误差|>50持续约0.96秒。',
    '- D（Kp0.5/±0.8）MAE20.2 µT，P95 39.3 µT，无|误差|>50区间；实际限幅仅2.7%。D/F各一笔，不能据此确定孰优。',
    '- C相同参数两次MAE为53.7/19.2 µT，两次响应曲线之间MAE约50.6 µT。两个基线B0y为2987.50/2929.31 µT，差58.19 µT；这提示检查空载基线与接触状态一致性，但不能把B0y差直接等同于标量误差或据此修改基线。',
    '- 各参数按时间顺序试验，起始平台实测值总体随顺序上升；Kp效应与笔间条件/时间效应混杂。本轮不能声称Kp越大必然越好。',
    '- 七笔TCP无无效读取，实际Z与命令Z的MAE约0.085–0.113 mm，完整回程均完成。10 Hz姿态诊断不排除更高频误差。',
    '- 下一步先聚焦D/F：先F再D各补一次，固定沾水、纸面与等待姿态并记录操作变化；无需立刻补齐六组第二轮。若复测仍有几十µT笔间偏移，再做固定Z短平台的局部重复性实验，先解释基线/接触差异。',
    '', '原始数据和执行器代码未修改。此文件为初筛，完整逐笔指标及来源哈希见summary.json。']
(OUT/'简析.md').write_text('\n'.join(lines)+'\n')
print('Saved first-round review: 7 complete runs; no exclusions.')
