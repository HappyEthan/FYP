"""Frozen four-run comparison of the two shortlisted nonlinear FF/P settings."""
from pathlib import Path
import importlib.util
import json
import numpy as np

OUT=Path(__file__).resolve().parent
DAY=OUT.parents[2]
RAW=OUT.parents[1]/'raw'
SOURCE=DAY/'06_非线性前馈难曲线对比/analysis/nonlinear_ff_p_selected_20260925/analyze.py'
spec=importlib.util.spec_from_file_location('measurement_audit',SOURCE)
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
import matplotlib.pyplot as plt

PREFIXES=['18-09-15','18-25-53','18-14-14','18-28-26']
runs=[]
for prefix in PREFIXES:
    matches=list(RAW.glob(prefix+'*'));assert len(matches)==1
    r=base.load(matches[0]);assert r['audit']['eligible']
    r['label']=prefix.replace('-',':')
    runs.append(r)
assert len({tuple(r['audit']['hashes'][k] for k in
    ['strokeplan.npz','feedforward.json','settings.json','entry_profile.json']) for r in runs})==1
groups={}
for kp,rr in [(.5,runs[:2]),(1.,runs[2:])]:
    for r in rr:
        c=r['audit']['control']
        assert (c['kp'],c['ki'],c['max_correction_mm'],c['max_correction_speed_mm_s'],
                c['max_correction_accel_mm_s2'],c['taper_ticks'])==(kp,0.,.8,2.,30.,50)
    e=np.concatenate([r['e'] for r in rr]);diff=rr[0]['y']-rr[1]['y']
    groups[str(kp)]=dict(mean_mae_uT=float(abs(e).mean()),pooled_p95_uT=float(np.percentile(abs(e),95)),
        within20_pct=float(np.mean(abs(e)<=20)*100),mean_severe50_s=float(np.mean([r['metrics']['severe50_s'] for r in rr])),
        repeat_curve_difference_mae_uT=float(abs(diff).mean()))
for r in runs:
    mask=r['t']>3+1e-8
    r['post3_diagnostic']=dict(mae_uT=float(abs(r['e'][mask]).mean()),within20_pct=float(np.mean(abs(r['e'][mask])<=20)*100))
summary=dict(method='Full measure_00 40s/2001 points, original logged EMA .3; no trimming or lag alignment. Post3 is diagnostic only.',
    chronological_order=['18-09-15 kp0.5','18-14-14 kp1','18-25-53 kp0.5','18-28-26 kp1'],
    caveat='Both rounds used 0.5 then 1; n=2 per condition, order/contact/baseline changes are not isolated.',
    groups=groups,runs=[dict(**r['audit'],metrics=r['metrics'],segments=r['segments'],post3_diagnostic=r['post3_diagnostic']) for r in runs])
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')

fig,axes=plt.subplots(2,2,figsize=(14,8.2),sharex=True,layout='constrained')
colors=['#2563eb','#0891b2','#ea580c','#a855f7']
for col,rr,kp in [(0,runs[:2],.5),(1,runs[2:],1.)]:
    ax=axes[0,col];r=rr[0]
    ax.fill_between(r['t'],r['g']-20,r['g']+20,color='#94a3b8',alpha=.18)
    ax.plot(r['t'],r['g'],color='#111827',lw=1.4,ls='--',label='目标（阴影±20 µT）')
    for j,r in enumerate(rr):
        color=colors[2*col+j];m=r['metrics']
        ax.plot(r['t'],r['y'],lw=1.1,color=color,label=f"{r['label']} · MAE {m['mae_uT']:.1f} · ±20内 {m['within20_pct']:.1f}%")
        axes[1,col].plot(r['t'],r['e'],lw=1.1,color=color,label=r['label'])
    ax.set(title=f'Kp={kp:g}，修正±0.8 mm：两次实测',ylabel='磁响应 / µT',ylim=(80,290))
    ax.legend(fontsize=8.5,loc='lower right')
    ax=axes[1,col];ax.axhspan(-20,20,color='#16a34a',alpha=.1);ax.axhline(0,color='gray',lw=.8)
    ax.set(title='有符号误差：正值偏高，负值偏低',ylabel='实测 − 目标 / µT',xlabel='测量时间 / s',ylim=(-80,80));ax.legend(fontsize=9)
for ax in axes.flat:ax.grid(alpha=.2);ax.set_xlim(0,40)
fig.suptitle('补录结果：Kp=1 的两次总体误差均较低，但笔间偏差仍改变方向\n共同限制：修正速度2 mm/s，加速度30 mm/s²，渐变1 s；完整40 s统计',fontsize=15)
fig.savefig(OUT/'候选参数复测对比.png',dpi=180,bbox_inches='tight')
fig.savefig(OUT/'候选参数复测对比.pdf',bbox_inches='tight');plt.close(fig)

rows=[]
for r in runs:
    m=r['metrics'];c=r['audit']['control']
    rows.append(f"| {r['label']} | {c['kp']:g} | {m['mae_uT']:.2f} | {m['p95_abs_uT']:.2f} | {m['within20_pct']:.2f}% | {m['bias_uT']:+.2f} | {m['severe50_s']:.2f} | {m['amplitude_cap_pct']:.2f}% |")
report='''---
project: 04-robot-control
status: active
---

# Kp0.5与Kp1：±0.8 mm候选复测

新增18:25:53（Kp0.5）和18:28:26（Kp1）均completed，2001个连续测量点、完整40秒。与各自第一次组成两次重复。四笔共同输入哈希一致，manifest快照哈希验证通过，测量引用的sensor行均valid。所有主指标保留完整40秒，不删除首段或重新对齐信号。

| 时间 | Kp | MAE/µT | P95绝对误差/µT | ±20内 | 平均有符号误差/µT | >50µT总时长/s | 实际幅值限幅占比 |
|---|---:|---:|---:|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

![四笔对比](候选参数复测对比.png)

## 结论

- 当前优先采用Kp=1、Ki=0、修正±0.8 mm、修正速度2 mm/s、加速度30 mm/s²、渐变1秒作为后续试验基准。其两笔MAE均低于Kp0.5两笔。这里只是现有候选比较，不宣称全局最优。
- Kp0.5两笔平均MAE23.30 µT、±20比例48.00%、合并P95 49.13 µT；Kp1对应16.58 µT、65.84%、42.20 µT。MAE描述性下降约28.9%，超过50 µT的每笔平均时长由1.77秒降至0.52秒。
- Kp1的两笔平均偏差为+11.01与−9.81 µT，方向改变；两次实测曲线之间MAE20.83 µT，高于Kp0.5的13.17 µT。因此“跟踪误差两次都较低”不等于信号曲线重复性已解决。不能用两笔正负偏差抵消后的均值冒充无偏。
- Kp1第一笔目标下降段平均偏高25.18 µT，第二笔仅偏高1.71 µT。此前观察到的下降段偏高不是每笔同样严重，尚不足以据此固定加入一个回升补偿。
- 新Kp1笔的首次160 µT平台平均偏低38.48 µT；完整40秒MAE16.13 µT、±20比例69.87%。单独诊断3秒以后为14.31 µT和75.57%；这不是主评分，首段仍计入全部正式指标。
- Kp1新笔实际限幅23.59%（下压21.34%、抬高2.25%），旧笔限幅34.18%且几乎都在抬高上限。修正方向随笔间状态明显变化，暂不继续盲目增大行程。

## 执行与采集

两笔新增TCP均无无效样本，最大单次读取分别25.80/18.45 ms；它们使用独立采集连接。对应测量控制最大间隔21.04/20.96 ms，未出现中止。Z跟随MAE分别0.103/0.119 mm，P95分别0.287/0.313 mm；约10 Hz的诊断不能排除高频误差。

Kp1两次B0y分别2916.94与2958.18 µT，相差41.24 µT；Kp0.5两次为2939.44与2982.42 µT。基线变化需要结合机械接触/沾水/磁状态判断，不能直接把B0y差当作标量磁响应误差，或人为修改基线让曲线贴合。

## 后续范围

无需立即恢复完整六组扫描。保留Kp1/±0.8作为工作基准，优先安排同一进笔方式下固定Z短平台的局部重复性检查，比较进笔后、经历深压后回到同Z的信号；同时记录空载基线和操作变化，区分笔内加载历史与笔间状态偏移。根据该检查再决定局部增益调度或慢积分，不因一笔初始偏低直接全局下移前馈表。

实际顺序两轮都是Kp0.5→Kp1，没有实现反序；每组仅两笔，时间、接触状态与参数效应尚未分离。以上为描述性结果。原始数据、前馈表及控制参数均未修改。

机器可读指标、输入和原始文件哈希见summary.json。源笔次时间前缀固定在review.py中，后续新增记录不会改变本次选取。
'''
(OUT/'分析报告.md').write_text(report)
print(json.dumps(groups,ensure_ascii=False,indent=2))
